# Ejercicio 1
class Ejercicio1:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 1: {self.valor}"

e = Ejercicio1("resultado")
print(e.mostrar())

# Ejercicio 2
class Ejercicio2:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 2: {self.valor}"

e = Ejercicio2("resultado")
print(e.mostrar())

# Ejercicio 3
class Ejercicio3:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 3: {self.valor}"

e = Ejercicio3("resultado")
print(e.mostrar())

# Ejercicio 4
class Ejercicio4:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 4: {self.valor}"

e = Ejercicio4("resultado")
print(e.mostrar())

# Ejercicio 5
class Ejercicio5:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 5: {self.valor}"

e = Ejercicio5("resultado")
print(e.mostrar())

# Ejercicio 6
class Ejercicio6:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 6: {self.valor}"

e = Ejercicio6("resultado")
print(e.mostrar())

# Ejercicio 7
class Ejercicio7:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 7: {self.valor}"

e = Ejercicio7("resultado")
print(e.mostrar())

# Ejercicio 8
class Ejercicio8:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 8: {self.valor}"

e = Ejercicio8("resultado")
print(e.mostrar())

# Ejercicio 9
class Ejercicio9:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 9: {self.valor}"

e = Ejercicio9("resultado")
print(e.mostrar())

# Ejercicio 10
class Ejercicio10:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 10: {self.valor}"

e = Ejercicio10("resultado")
print(e.mostrar())

# Ejercicio 11
class Ejercicio11:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 11: {self.valor}"

e = Ejercicio11("resultado")
print(e.mostrar())

# Ejercicio 12
class Ejercicio12:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 12: {self.valor}"

e = Ejercicio12("resultado")
print(e.mostrar())

# Ejercicio 13
class Ejercicio13:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 13: {self.valor}"

e = Ejercicio13("resultado")
print(e.mostrar())

# Ejercicio 14
class Ejercicio14:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 14: {self.valor}"

e = Ejercicio14("resultado")
print(e.mostrar())

# Ejercicio 15
class Ejercicio15:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 15: {self.valor}"

e = Ejercicio15("resultado")
print(e.mostrar())

# Ejercicio 16
class Ejercicio16:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 16: {self.valor}"

e = Ejercicio16("resultado")
print(e.mostrar())

# Ejercicio 17
class Ejercicio17:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 17: {self.valor}"

e = Ejercicio17("resultado")
print(e.mostrar())

# Ejercicio 18
class Ejercicio18:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 18: {self.valor}"

e = Ejercicio18("resultado")
print(e.mostrar())

# Ejercicio 19
class Ejercicio19:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 19: {self.valor}"

e = Ejercicio19("resultado")
print(e.mostrar())

# Ejercicio 20
class Ejercicio20:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 20: {self.valor}"

e = Ejercicio20("resultado")
print(e.mostrar())

# Ejercicio 21
class Ejercicio21:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 21: {self.valor}"

e = Ejercicio21("resultado")
print(e.mostrar())

# Ejercicio 22
class Ejercicio22:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 22: {self.valor}"

e = Ejercicio22("resultado")
print(e.mostrar())

# Ejercicio 23
class Ejercicio23:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 23: {self.valor}"

e = Ejercicio23("resultado")
print(e.mostrar())

# Ejercicio 24
class Ejercicio24:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 24: {self.valor}"

e = Ejercicio24("resultado")
print(e.mostrar())

# Ejercicio 25
class Ejercicio25:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 25: {self.valor}"

e = Ejercicio25("resultado")
print(e.mostrar())

# Ejercicio 26
class Ejercicio26:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 26: {self.valor}"

e = Ejercicio26("resultado")
print(e.mostrar())

# Ejercicio 27
class Ejercicio27:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 27: {self.valor}"

e = Ejercicio27("resultado")
print(e.mostrar())

# Ejercicio 28
class Ejercicio28:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 28: {self.valor}"

e = Ejercicio28("resultado")
print(e.mostrar())

# Ejercicio 29
class Ejercicio29:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 29: {self.valor}"

e = Ejercicio29("resultado")
print(e.mostrar())

# Ejercicio 30
class Ejercicio30:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 30: {self.valor}"

e = Ejercicio30("resultado")
print(e.mostrar())

# Ejercicio 31
class Ejercicio31:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 31: {self.valor}"

e = Ejercicio31("resultado")
print(e.mostrar())

# Ejercicio 32
class Ejercicio32:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 32: {self.valor}"

e = Ejercicio32("resultado")
print(e.mostrar())

# Ejercicio 33
class Ejercicio33:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 33: {self.valor}"

e = Ejercicio33("resultado")
print(e.mostrar())

# Ejercicio 34
class Ejercicio34:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 34: {self.valor}"

e = Ejercicio34("resultado")
print(e.mostrar())

# Ejercicio 35
class Ejercicio35:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 35: {self.valor}"

e = Ejercicio35("resultado")
print(e.mostrar())

# Ejercicio 36
class Ejercicio36:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 36: {self.valor}"

e = Ejercicio36("resultado")
print(e.mostrar())

# Ejercicio 37
class Ejercicio37:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 37: {self.valor}"

e = Ejercicio37("resultado")
print(e.mostrar())

# Ejercicio 38
class Ejercicio38:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 38: {self.valor}"

e = Ejercicio38("resultado")
print(e.mostrar())

# Ejercicio 39
class Ejercicio39:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 39: {self.valor}"

e = Ejercicio39("resultado")
print(e.mostrar())

# Ejercicio 40
class Ejercicio40:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 40: {self.valor}"

e = Ejercicio40("resultado")
print(e.mostrar())

# Ejercicio 41
class Ejercicio41:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 41: {self.valor}"

e = Ejercicio41("resultado")
print(e.mostrar())

# Ejercicio 42
class Ejercicio42:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 42: {self.valor}"

e = Ejercicio42("resultado")
print(e.mostrar())

# Ejercicio 43
class Ejercicio43:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 43: {self.valor}"

e = Ejercicio43("resultado")
print(e.mostrar())

# Ejercicio 44
class Ejercicio44:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 44: {self.valor}"

e = Ejercicio44("resultado")
print(e.mostrar())

# Ejercicio 45
class Ejercicio45:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 45: {self.valor}"

e = Ejercicio45("resultado")
print(e.mostrar())

# Ejercicio 46
class Ejercicio46:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 46: {self.valor}"

e = Ejercicio46("resultado")
print(e.mostrar())

# Ejercicio 47
class Ejercicio47:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 47: {self.valor}"

e = Ejercicio47("resultado")
print(e.mostrar())

# Ejercicio 48
class Ejercicio48:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 48: {self.valor}"

e = Ejercicio48("resultado")
print(e.mostrar())

# Ejercicio 49
class Ejercicio49:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 49: {self.valor}"

e = Ejercicio49("resultado")
print(e.mostrar())

# Ejercicio 50
class Ejercicio50:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 50: {self.valor}"

e = Ejercicio50("resultado")
print(e.mostrar())

# Ejercicio 51
class Ejercicio51:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 51: {self.valor}"

e = Ejercicio51("resultado")
print(e.mostrar())

# Ejercicio 52
class Ejercicio52:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 52: {self.valor}"

e = Ejercicio52("resultado")
print(e.mostrar())

# Ejercicio 53
class Ejercicio53:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 53: {self.valor}"

e = Ejercicio53("resultado")
print(e.mostrar())

# Ejercicio 54
class Ejercicio54:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 54: {self.valor}"

e = Ejercicio54("resultado")
print(e.mostrar())

# Ejercicio 55
class Ejercicio55:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 55: {self.valor}"

e = Ejercicio55("resultado")
print(e.mostrar())

# Ejercicio 56
class Ejercicio56:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 56: {self.valor}"

e = Ejercicio56("resultado")
print(e.mostrar())

# Ejercicio 57
class Ejercicio57:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 57: {self.valor}"

e = Ejercicio57("resultado")
print(e.mostrar())

# Ejercicio 58
class Ejercicio58:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 58: {self.valor}"

e = Ejercicio58("resultado")
print(e.mostrar())

# Ejercicio 59
class Ejercicio59:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 59: {self.valor}"

e = Ejercicio59("resultado")
print(e.mostrar())

# Ejercicio 60
class Ejercicio60:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 60: {self.valor}"

e = Ejercicio60("resultado")
print(e.mostrar())

# Ejercicio 61
class Ejercicio61:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 61: {self.valor}"

e = Ejercicio61("resultado")
print(e.mostrar())

# Ejercicio 62
class Ejercicio62:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 62: {self.valor}"

e = Ejercicio62("resultado")
print(e.mostrar())

# Ejercicio 63
class Ejercicio63:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 63: {self.valor}"

e = Ejercicio63("resultado")
print(e.mostrar())

# Ejercicio 64
class Ejercicio64:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 64: {self.valor}"

e = Ejercicio64("resultado")
print(e.mostrar())

# Ejercicio 65
class Ejercicio65:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 65: {self.valor}"

e = Ejercicio65("resultado")
print(e.mostrar())

# Ejercicio 66
class Ejercicio66:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 66: {self.valor}"

e = Ejercicio66("resultado")
print(e.mostrar())

# Ejercicio 67
class Ejercicio67:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 67: {self.valor}"

e = Ejercicio67("resultado")
print(e.mostrar())

# Ejercicio 68
class Ejercicio68:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 68: {self.valor}"

e = Ejercicio68("resultado")
print(e.mostrar())

# Ejercicio 69
class Ejercicio69:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 69: {self.valor}"

e = Ejercicio69("resultado")
print(e.mostrar())

# Ejercicio 70
class Ejercicio70:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 70: {self.valor}"

e = Ejercicio70("resultado")
print(e.mostrar())

# Ejercicio 71
class Ejercicio71:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 71: {self.valor}"

e = Ejercicio71("resultado")
print(e.mostrar())

# Ejercicio 72
class Ejercicio72:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 72: {self.valor}"

e = Ejercicio72("resultado")
print(e.mostrar())

# Ejercicio 73
class Ejercicio73:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 73: {self.valor}"

e = Ejercicio73("resultado")
print(e.mostrar())

# Ejercicio 74
class Ejercicio74:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 74: {self.valor}"

e = Ejercicio74("resultado")
print(e.mostrar())

# Ejercicio 75
class Ejercicio75:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 75: {self.valor}"

e = Ejercicio75("resultado")
print(e.mostrar())

# Ejercicio 76
class Ejercicio76:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 76: {self.valor}"

e = Ejercicio76("resultado")
print(e.mostrar())

# Ejercicio 77
class Ejercicio77:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 77: {self.valor}"

e = Ejercicio77("resultado")
print(e.mostrar())

# Ejercicio 78
class Ejercicio78:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 78: {self.valor}"

e = Ejercicio78("resultado")
print(e.mostrar())

# Ejercicio 79
class Ejercicio79:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 79: {self.valor}"

e = Ejercicio79("resultado")
print(e.mostrar())

# Ejercicio 80
class Ejercicio80:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 80: {self.valor}"

e = Ejercicio80("resultado")
print(e.mostrar())

# Ejercicio 81
class Ejercicio81:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 81: {self.valor}"

e = Ejercicio81("resultado")
print(e.mostrar())

# Ejercicio 82
class Ejercicio82:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 82: {self.valor}"

e = Ejercicio82("resultado")
print(e.mostrar())

# Ejercicio 83
class Ejercicio83:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 83: {self.valor}"

e = Ejercicio83("resultado")
print(e.mostrar())

# Ejercicio 84
class Ejercicio84:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 84: {self.valor}"

e = Ejercicio84("resultado")
print(e.mostrar())

# Ejercicio 85
class Ejercicio85:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 85: {self.valor}"

e = Ejercicio85("resultado")
print(e.mostrar())

# Ejercicio 86
class Ejercicio86:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 86: {self.valor}"

e = Ejercicio86("resultado")
print(e.mostrar())

# Ejercicio 87
class Ejercicio87:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 87: {self.valor}"

e = Ejercicio87("resultado")
print(e.mostrar())

# Ejercicio 88
class Ejercicio88:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 88: {self.valor}"

e = Ejercicio88("resultado")
print(e.mostrar())

# Ejercicio 89
class Ejercicio89:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 89: {self.valor}"

e = Ejercicio89("resultado")
print(e.mostrar())

# Ejercicio 90
class Ejercicio90:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 90: {self.valor}"

e = Ejercicio90("resultado")
print(e.mostrar())

# Ejercicio 91
class Ejercicio91:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 91: {self.valor}"

e = Ejercicio91("resultado")
print(e.mostrar())

# Ejercicio 92
class Ejercicio92:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 92: {self.valor}"

e = Ejercicio92("resultado")
print(e.mostrar())

# Ejercicio 93
class Ejercicio93:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 93: {self.valor}"

e = Ejercicio93("resultado")
print(e.mostrar())

# Ejercicio 94
class Ejercicio94:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 94: {self.valor}"

e = Ejercicio94("resultado")
print(e.mostrar())

# Ejercicio 95
class Ejercicio95:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 95: {self.valor}"

e = Ejercicio95("resultado")
print(e.mostrar())

# Ejercicio 96
class Ejercicio96:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 96: {self.valor}"

e = Ejercicio96("resultado")
print(e.mostrar())

# Ejercicio 97
class Ejercicio97:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 97: {self.valor}"

e = Ejercicio97("resultado")
print(e.mostrar())

# Ejercicio 98
class Ejercicio98:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 98: {self.valor}"

e = Ejercicio98("resultado")
print(e.mostrar())

# Ejercicio 99
class Ejercicio99:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 99: {self.valor}"

e = Ejercicio99("resultado")
print(e.mostrar())

# Ejercicio 100
class Ejercicio100:
    def __init__(self, valor):
        self.valor = valor
    def mostrar(self):
        return f"Ejercicio 100: {self.valor}"

e = Ejercicio100("resultado")
print(e.mostrar())

